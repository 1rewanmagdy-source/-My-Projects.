/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UniversityManagementGUI {
   
    private JFrame frame;

  
    private JButton btnLogin, btnStudent, btnFaculty, btnAdmin;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JLabel lblUsername, lblPassword, lblWelcome;

    public UniversityManagementGUI() {
       
        frame = new JFrame("University Management System");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        initializeComponents();
    }

    
    private void initializeComponents() {
    
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridLayout(3, 2));

        lblUsername = new JLabel("Username:");
        lblPassword = new JLabel("Password:");
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();

        loginPanel.add(lblUsername);
        loginPanel.add(txtUsername);
        loginPanel.add(lblPassword);
        loginPanel.add(txtPassword);

        
        btnLogin = new JButton("Login");
        loginPanel.add(btnLogin);
        frame.add(loginPanel, BorderLayout.CENTER);

    
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = txtUsername.getText();
                String password = new String(txtPassword.getPassword());

                if (validateCredentials(username, password)) {
                    showUserMenu();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid Username or Password");
                }
            }
        });

        frame.setVisible(true);
    }

    
    private boolean validateCredentials(String username, String password) {
     
        return username.equals("admin") && password.equals("1234");
    }

 
    private void showUserMenu() {
        
        frame.getContentPane().removeAll();

      
        JPanel userMenuPanel = new JPanel();
        userMenuPanel.setLayout(new FlowLayout());

        lblWelcome = new JLabel("Welcome, Admin!");
        userMenuPanel.add(lblWelcome);

     
        btnStudent = new JButton("Student Menu");
        btnFaculty = new JButton("Faculty Menu");
        btnAdmin = new JButton("Admin Menu");

        userMenuPanel.add(btnStudent);
        userMenuPanel.add(btnFaculty);
        userMenuPanel.add(btnAdmin);

       
        btnStudent.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Student Menu Clicked");
            }
        });
        btnFaculty.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Faculty Menu Clicked");
            }
        });
        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Admin Menu Clicked");
            }
        });

        frame.add(userMenuPanel, BorderLayout.CENTER);
        frame.revalidate();
        frame.repaint();
    }

    public static void main(String[] args) {
        
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new UniversityManagementGUI();
            }
        });
    }
}

