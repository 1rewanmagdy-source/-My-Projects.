/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import java.util.Scanner;

public class UserInterface {
    private University university;
    private Scanner scanner;

    public UserInterface(University university) {
        this.university = university;
        this.scanner = new Scanner(System.in);
    }

    public void showMainMenu() {
        System.out.println("Welcome to the University System");
        System.out.println("1. Student Menu");
        System.out.println("2. Faculty Menu");
        System.out.println("3. Exit");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        switch (choice) {
            case 1:
                showStudentMenu();
                break;
            case 2:
                showFacultyMenu();
                break;
            case 3:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice, please try again.");
                showMainMenu();
                break;
        }
    }

    public void showStudentMenu() {
        System.out.println("Student Menu:");
        System.out.println("1. View Courses");
        System.out.println("2. View Grades");
        System.out.println("3. Go Back");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        switch (choice) {
            case 1:
                viewCourses();
                break;
            case 2:
                viewGrades();
                break;
            case 3:
                showMainMenu();
                break;
            default:
                System.out.println("Invalid choice, please try again.");
                showStudentMenu();
                break;
        }
    }

    public void showFacultyMenu() {
        System.out.println("Faculty Menu:");
        System.out.println("1. Assign Grade");
        System.out.println("2. View Course Enrollment");
        System.out.println("3. Go Back");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        switch (choice) {
            case 1:
                assignGrade();
                break;
            case 2:
                viewCourseEnrollment();
                break;
            case 3:
                showMainMenu();
                break;
            default:
                System.out.println("Invalid choice, please try again.");
                showFacultyMenu();
                break;
        }
    }

    private void viewCourses() {
        System.out.println("Available Courses:");
        for (Course course : university.getCourses()) {
            System.out.println(course);
        }
        showStudentMenu();
    }

    private void viewGrades() {
        // In a real system, we'd fetch grades from a database or file
        System.out.println("Student Grades: TBD");
        showStudentMenu();
    }

    private void assignGrade() {
        // Here, Faculty assigns grades. We can simulate assigning a grade to a course
        System.out.println("Enter course code to assign grade: ");
        String courseCode = scanner.nextLine();
        System.out.println("Enter grade to assign: ");
        double grade = scanner.nextDouble();
        Faculty faculty = (Faculty) university.getUsers().get(1); // Simplified for demo
        faculty.assignGrade(grade);
        showFacultyMenu();
    }

    private void viewCourseEnrollment() {
        // Show enrolled courses for faculty
        System.out.println("Courses you are teaching: ");
        // We can display enrolled students here
        showFacultyMenu();
}
}
