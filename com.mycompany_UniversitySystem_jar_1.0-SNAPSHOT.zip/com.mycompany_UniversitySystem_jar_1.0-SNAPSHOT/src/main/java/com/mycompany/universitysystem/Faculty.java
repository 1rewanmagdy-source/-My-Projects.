/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
public class Faculty extends User implements GradingSystem {
    private String department;

    public Faculty(String userId, String password, String role, String department) {
        super(userId, password, role);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    
    public void assignGrade(double grade) {
        System.out.println("Assigning grade: " + grade + " for Faculty in " + department + " department.");
    }

    @Override
    public void displayMenu() {
        System.out.println("Faculty Menu:");
        System.out.println("1. Assign Grade");
        System.out.println("2. View Course Enrollment");
    }

    @Override
    public String toString() {
        return "Faculty{" +
                "userId='" + getUserId() + '\'' +
                ", department='" + department ;}
}

