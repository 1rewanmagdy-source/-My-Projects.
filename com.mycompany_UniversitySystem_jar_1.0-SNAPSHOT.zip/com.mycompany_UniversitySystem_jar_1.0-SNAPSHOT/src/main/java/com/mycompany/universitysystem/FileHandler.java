/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import java.io.*;
import java.util.*;

public class FileHandler {
    public static void saveUsersToFile(List<User> users) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"))) {
            for (User user : users) {
                writer.write(user.getUserId() + "," + user.getPassword() + "," + user.getRole() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error writing users to file: " + e.getMessage());
        }
    }

    public static void loadUsersFromFile(List<User> users) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                String userId = userData[0];
                String password = userData[1];
                String role = userData[2];
                // Add users based on role, for simplicity just add as User
                users.add(new User(userId, password, role) {
                    @Override
                    public void displayMenu() {
                        System.out.println("Generic User Menu");
                    }

                    @Override
                    public String toString() {
                        return "User{userId='" + userId + "', role='" + role + "'}";
                    }
                });
            }
        } catch (IOException e) {
            System.out.println("Error reading users from file: " + e.getMessage());
        }
    }
}
