/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import java.io.*;
import java.util.ArrayList;

public class University {
    private ArrayList<User> users;
    private ArrayList<Course> courses;
    private ArrayList<Department> departments;

    public University() {
        users = new ArrayList<>();
        courses = new ArrayList<>();
        departments = new ArrayList<>();
    }

    public void addUser(User user) {
        users.add(user);
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addDepartment(Department department) {
        departments.add(department);
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Course> getCourses() {
        return courses;
    }

    public ArrayList<Department> getDepartments() {
        return departments;
    }

    // Save data to text files
    public void saveData() {
        try {
            // Save users
            BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt"));
            for (User user : users) {
                writer.write(user.getUserId() + "," + user.getPassword() + "," + user.getRole() + "\n");
            }
            writer.close();

            // Save courses
            writer = new BufferedWriter(new FileWriter("courses.txt"));
            for (Course course : courses) {
                writer.write(course.getCourseCode() + "," + course.getCourseName() + "," + course.getCapacity() + "\n");
            }
            writer.close();

            // Save departments
            writer = new BufferedWriter(new FileWriter("departments.txt"));
            for (Department department : departments) {
                writer.write(department.getDepartmentName() + "\n");
                for (Faculty faculty : department.getFacultyList()) {
                    writer.write(faculty.getUserId() + "\n");
                }
            }
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Load data from files
    public void loadData() {
        // Similar to the saveData method, you will write code to load users, courses, and departments
}
}