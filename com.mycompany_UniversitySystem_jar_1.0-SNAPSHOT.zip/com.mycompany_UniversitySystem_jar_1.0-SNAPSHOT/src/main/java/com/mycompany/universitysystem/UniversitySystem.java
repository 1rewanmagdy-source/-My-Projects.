/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import java.io.*;
import java.util.*;
public class UniversitySystem {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("===== University Management System =====");

        System.out.print("Enter User ID: ");
        String userId = scanner.nextLine();

        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        User user = authenticate(userId, password);
        if (user == null) {
            System.out.println("❌ Login failed.");
            return;
        }

        System.out.println("✅ Logged in as " + user.getRole());

        switch (user.getRole()) {
            case "Student" -> studentMenu((Student) user);
            case "Faculty" -> facultyMenu((Faculty) user);
            case "AdminStaff" -> adminMenu();
            default -> System.out.println("Unsupported role.");
        }
    }

    private static User authenticate(String id, String pass) {
        try (BufferedReader reader = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts[0].equals(id) && parts[2].equals(pass)) {
                    String role = parts[6];
                    
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading users.txt");
        }
        return null;
    }

    private static void studentMenu(Student s) {
        int choice;
        do {
            System.out.println("\n--- Student Menu ---");
            System.out.println("1. View My Enrollments\n2. Generate Report\n3. Logout");
            System.out.print("Choice: ");
            choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1 -> viewStudentEnrollments(s.getUserId());
             
                case 2 -> System.out.println("Logging out...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 3);
    }

    private static void facultyMenu(Faculty f) {
        int choice;
        do {
            System.out.println("\n--- Faculty Menu ---");
            System.out.println("1. View All Enrollments\n2. Generate Report\n3. Logout");
            System.out.print("Choice: ");
            choice = Integer.parseInt(scanner.nextLine());
            switch (choice) {
                case 1 -> viewAllEnrollments();
                
                case 2 -> System.out.println("Logging out...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 3);
    }

    private static void adminMenu() {
        int choice;
        do {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Register Student\n2. Add Course\n3. Logout");
            System.out.print("Choice: ");
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1 -> registerStudent();
                case 2 -> addCourse();
                case 3 -> System.out.println("Logging out...");
                default -> System.out.println("Invalid choice.");
            }
        } while (choice != 3);
    }

    private static void registerStudent() {
        System.out.print("ID: ");
        String id = scanner.nextLine();
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String pass = scanner.nextLine();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("users.txt", true))) {
            writer.write(id + "," + username + "," + pass + ",StudentName,email@uni.com,012345,Student");
            writer.newLine();
            System.out.println("✅ Student registered.");
        } catch (IOException e) {
            System.out.println("Error writing user.");
        }
    }

    private static void addCourse() {
        System.out.print("Course ID: ");
        String id = scanner.nextLine();
        System.out.print("Title: ");
        String title = scanner.nextLine();
        System.out.print("Type (Lecture/Lab): ");
        String type = scanner.nextLine();
        System.out.print("Hours: ");
        int hrs = Integer.parseInt(scanner.nextLine());

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("courses.txt", true))) {
            if (type.equalsIgnoreCase("Lecture"))
                writer.write(id + "," + title + ",Lecture," + hrs);
            else if (type.equalsIgnoreCase("Lab"))
                writer.write(id + "," + title + ",Lab," + hrs);
            else {
                System.out.println("❌ Invalid type.");
                return;
            }
            writer.newLine();
            System.out.println("✅ Course added.");
        } catch (IOException e) {
            System.out.println("Error writing course.");
        }
    }

    private static void viewStudentEnrollments(String studentId) {
        try (BufferedReader reader = new BufferedReader(new FileReader("enrollments.txt"))) {
            String line;
            System.out.println("--- Your Enrollments ---");
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(studentId + ",")) {
                    System.out.println(line);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading enrollments.");
        }
    }

    private static void viewAllEnrollments() {
        try (BufferedReader reader = new BufferedReader(new FileReader("enrollments.txt"))) {
            String line;
            System.out.println("--- All Enrollments ---");
            while ((line = reader.readLine()) != null)
                System.out.println(line);
        } catch (IOException e) {
            System.out.println("Error reading enrollments.");
 }
}
}