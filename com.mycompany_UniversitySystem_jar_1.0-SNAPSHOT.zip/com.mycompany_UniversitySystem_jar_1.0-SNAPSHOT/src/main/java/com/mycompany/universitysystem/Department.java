/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.universitysystem;

/**
 *
 * @author DREAM8638
 */
import java.util.ArrayList;

public class Department {
    private String departmentName;
    private ArrayList<Faculty> facultyList;

    public Department(String departmentName) {
        this.departmentName = departmentName;
        this.facultyList = new ArrayList<>();
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public void addFaculty(Faculty faculty) {
        this.facultyList.add(faculty);
    }

    public ArrayList<Faculty> getFacultyList() {
        return facultyList;
}
}
